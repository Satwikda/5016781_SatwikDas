public class AdapterPatternExample {
    public static void main(String[] args) {
        
        PayPal payPal = new PayPal();
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPal);
        payPalAdapter.processPayment(100.0);

        
        Paytm paytm= new Paytm();
        PaymentProcessor paytmAdapter = new PaytmAdapter(paytm);
        paytmAdapter.processPayment(200.0);
    }
}