
interface Notifier {
    void send();
}