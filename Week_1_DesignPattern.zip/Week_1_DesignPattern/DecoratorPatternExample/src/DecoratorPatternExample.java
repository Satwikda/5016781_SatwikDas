public class DecoratorPatternExample {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        emailNotifier.send();

        Notifier smsDecorator = new SMSNotifierDecorator(emailNotifier);
        smsDecorator.send();

        Notifier slackDecorator = new SlackNotifierDecorator(smsDecorator);
        slackDecorator.send();
    }
}