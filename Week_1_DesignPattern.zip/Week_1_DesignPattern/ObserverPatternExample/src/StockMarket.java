import java.util.ArrayList;
import java.util.List;

class StockMarket implements Stock {
    private List<Observer> observers = new ArrayList<>();
    private double stockPrice;

    public StockMarket(double initialStockPrice) {
        this.stockPrice = initialStockPrice;
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void deregisterObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(stockPrice);
        }
    }

    public void setStockPrice(double newStockPrice) {
        this.stockPrice = newStockPrice;
        notifyObservers();
    }
}
