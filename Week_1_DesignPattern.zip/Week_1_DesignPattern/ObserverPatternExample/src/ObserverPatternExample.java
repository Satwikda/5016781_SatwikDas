
public class ObserverPatternExample {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket(100.0);

        MobileApp mobileApp = new MobileApp();
        WebApp webApp = new WebApp();

        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        stockMarket.setStockPrice(120.0); 
        stockMarket.setStockPrice(95.0); 

        stockMarket.deregisterObserver(mobileApp); 

        stockMarket.setStockPrice(115.0); 
    }
}